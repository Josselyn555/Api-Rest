<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }

    public function test1(){
        $variable= array(
            "id"=>"3458",
            "nombres"=>"josselyn",
            "apellidos"=>"Triviño",
            "cedula"=>"1314153998"
        );
        return $this->response->setJson($variable);
    }

    public function productInfo(){
        $product = array(
            "id"=>"22",
            "nombre"=>"Laptop",
            "marca"=>"Dell",
            "modelo"=>"Inspiron 15"
        );
        return $this->response->setJson($product);
    }

    public function bookDetails(){
        $book = array(
            "id"=>"33",
            "titulo"=>"Cien años de soledad",
            "autor"=>"Gabriel García Márquez",
            "isbn"=>"978-0060883287"
        );
        return $this->response->setJson($book);
    }

    public function studentInfo(){
        $student = array(
            "id"=>"44",
            "nombre"=>"Ana",
            "apellido"=>"Pérez",
            "matricula"=>"9876543210"
        );
        return $this->response->setJson($student);
    }

    public function orderDetails(){
        $order = array(
            "id"=>"55",
            "producto"=>"iPhone 13",
            "cantidad"=>"1",
            "precio"=>"$999"
        );
        return $this->response->setJson($order);
    }
}

